<?php
define ("DB_HOST", "localhost");
define ("DB_USER", "hci573");
define ("DB_PASS", "hci573");
define ("DB_NAME", "hci573");

//table names
define ("TABLE_AUTOCOMPLETE","table_autocomplete");
define ("TABLE_CHAPTERS","table_chapters");

//migrated to mysqli API
$link = mysqli_connect(DB_HOST, DB_USER, DB_PASS) or die("Couldn't make connection.");

//note that with mysqli, the first argument here is the connection to the server while the second is the name of the database
$db = mysqli_select_db($link,DB_NAME) or die("Couldn't select database");

/*Function to super sanitize anything going near our DBs*/
function filter($data)
{
	$data = trim(htmlentities(strip_tags($data)));

	if (get_magic_quotes_gpc())
	{
		$data = stripslashes($data);
	}

	$data = mysql_real_escape_string($data);
	return $data;
}

/* Part 2: A function which generates an SQL query using multiple search terms, executes it, and returns the results */
function get_results($search_terms_array){
	//TO DO: create the query
	$query = "SELECT * FROM " .TABLE_CHAPTERS . " WHERE ";
	
	for ($i = 0; $i < count($search_terms_array); $i++){
		$query .= "chapter_text LIKE '%" . $search_terms_array[$i] . "%' ";
		
		if ($i == count($search_terms_array) - 1){
			$query .= ";";
		}
		else $query .= " AND ";
	}
	
	
	echo $query . "<br>";

	global $link;
	$result = mysqli_query($link,$query) or die(mysqli_error($link));
	
	$results = array();
	while (true)
	{
		$row = mysqli_fetch_array($result);
			
		if (!$row) //if $row evaluates to 'false' (i.e., !$row evaluates to true) then we're done
			break;
			
		//add the next row at the end of the results array
		$results[] = $row;
	}
	
	return $results;
}

//Part 1: get search terms from the user entered text
function get_search_terms($entered_text){

	//step 1: sanitize the user's input
	$filtered_text = filter($entered_text);
	
	
	//step 2: split the input text into tokens 
	$terms = explode(" ",$filtered_text);
	
	
	return $terms;
}

//get search terms from the user entered text assuming the user may be using quotes
function get_search_terms_with_quotes($entered_text){

	//replace each quote "character" with an actual character
	$replace_quote_character = '$';
	$entered_text = str_replace('"',$replace_quote_character,$entered_text);

	//step 1: sanitize the user's input
	$filtered_text = filter($entered_text);

	//where to store the terms
	$results = array();
	
	//temporary buffer of characters
	$temp_buffer = "";
	
	//variable to represent the state
	$inside_quotes = false;
	
	for ($i = 0; $i < strlen($filtered_text); $i++){
		$current_character = $filtered_text[$i];
		
		//if the character isn't a space and isn't a quote, add it to the buffer
		if ($current_character != ' ' and $current_character != $replace_quote_character){
			$temp_buffer .= $current_character;
		}
		else if ($current_character == ' '){
			//if we are not inside the quotes, then add the buffer to the results
			if ( ! $inside_quotes ){
				if ($temp_buffer != ""){ //check if we have something stored in the buffer
					$results[] = $temp_buffer; //add the buffer
					$temp_buffer = ""; //clear the buffer
				}
			}
			else {
				//the space must be inside the quotes so it should be included in the buffer
				$temp_buffer .= $current_character;
			}
		}
		else if ($current_character == $replace_quote_character){
			//if we inside quotes, then this next quote must be the closing quote
			if ( $inside_quotes ){
				if ($temp_buffer != ""){ //check if we have something stored in the buffer
					$results[] = $temp_buffer; //add the buffer
					$temp_buffer = ""; //clear the buffer
				}
				$inside_quotes = false; // we are no longer inside the quotes
			}
			else { //else, this must be an opening quote
				$inside_quotes = true; // we are now inside the quotes -- nothing else to do until the next character is read
			}
		}
	}
	
	//finally, add whatever is left in the buffer
	if ($temp_buffer != "") //check if we have something stored in the buffer
		$results[] = $temp_buffer; //add the buffer
	
	return $results;
}


?>