<?php

require 'includes/constants/dbc.php';



if ($_POST){
	
	$entered_text = $_POST['search_terms'];
	
	
	
	$terms = get_search_terms_with_quotes($entered_text);
	print_r($terms);
	$search_results = get_results($terms);
}


?>


<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Search Exanple</title>

<!--include jquery UI css -->
</head>
<body>

<br>
<form id="my_form" method="post">
<div>
	Search Terms: 
	<input type="text" name="search_terms"><br>
	<br>
	
	
	<button type="submit" >Submit</button>
</div>

</form>

<div id="dynamic_content"></div>
	<?php
		if (isset($search_results)){
			echo "<p>Found " . count($search_results) . " matches:</p>";
			
			foreach ($search_results as $current_row){
				echo $current_row['chapter_text'];
				echo "<br><br>";
			}
		
		}
	?>
</body>

</html>


