<?php

function find_min_index($numbers){
	$current_min = $numbers[0];
	$current_min_index = 0;

	for ($i = 1; $i < count($numbers); $i++){
		if ($numbers[$i] < $current_min){
			$current_min = $numbers[$i];
			$current_min_index = $i;
		}
	}
	
	return $current_min_index;
}

function find_max_index($numbers){
	$current_max = $numbers[0];
	$current_max_index = 0;

	for ($i = 1; $i < count($numbers); $i++){
		if ($numbers[$i] > $current_max){
			$current_max = $numbers[$i];
			$current_max_index = $i;
		}
	}
	
	return $current_max_index;
}

function find_max($numbers){
	$current_max = $numbers[0];

	for ($i = 1; $i < count($numbers); $i++){
		if ($numbers[$i] > $current_max){
			$current_max = $numbers[$i];
		}
	}
	
	return $current_max;
}


function find_largest_three($numbers){

	$results = array();

	foreach ($numbers as $current_number){
		if ( count($results) < 3){
			$results[] = $current_number;
		}
		else {
			$current_min = find_min_index($results);
			
			if ($current_number > $results[$current_min]){
				$results[$current_min] = $current_number;
			}
		}
	
	}
	
	return $results;
}

//generate some random numbers
$x = array();
for ($i = 0; $i < 10; $i ++){
	$x[] = rand(0,100);
}

echo "Numbers: ";
print_r($x); echo "<br>";

//test the function

$y = find_largest_three($x);

print_r($y);





?>