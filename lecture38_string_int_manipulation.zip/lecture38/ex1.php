<?php

function my_tokenize($input_string){
	//Steps 1 and 2
	$results = array();
	$temp_buffer = "";
	
	//The main loop
	for ($i = 0; $i < strlen($input_string); $i ++){
		$current_character = $input_string[$i];
		
		if ($current_character == ' '){
			if ($temp_buffer != ""){ //check if we have something stored in the buffer
				$results[] = $temp_buffer; //add the buffer
				$temp_buffer = ""; //clear the buffer
			}
		}
		else {
			$temp_buffer .= $current_character;
		}
	
	}
	
	//finally, add whatever is left in the buffer
	if ($temp_buffer != "") //check if we have something stored in the buffer
		$results[] = $temp_buffer; //add the buffer
		
	return $results;
}


$search_input_value = "Smartphone Droid Free";

$start_time = microtime(true);

for ($i = 0; $i < 10000; $i ++){
	$tokens = my_tokenize($search_input_value);
}

$end_time = microtime(true);

echo "Time it took: "+$end_time-$start_time +"<br>";





?>