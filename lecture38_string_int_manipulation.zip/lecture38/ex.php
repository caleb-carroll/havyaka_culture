<?php

function my_tokenize($input_string){
	//Step 1: create a variable for the results
	
	//Step 2: create a variable for the temporary buffer
	
	//Step 3: use a for loop to iterate over the input string
		//as we read characters, we store them in the buffer
		//when reaching a space, add the content of the buffer to the list of results and reset the buffer
	
	//Step 4: after the end of the string is reached, add what's in the buffer to the list of results
	
	//Step 5: return the results
}


$search_input_value = "Smartphone Droid Free";






?>